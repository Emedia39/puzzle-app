<div>
    <!-- Simplicity is an acquired taste. - Katharine Gerould -->
</div>
<html lang=“ja”>
<body>
<h1>■ログイン画面</h1><!--変数で出力-->
</body>
</html>
　
<form method="post" action=<?php echo e(url('dologin')); ?>>
    <?php echo csrf_field(); ?><!--CSRF来策・やらないとララベルが判断して419エラー-->
    <input name="name">
    <input name="password">
    <input type="submit" name='doLogin'></input>
</form>
<?php /**PATH /var/www/resources/views/accounts/login.blade.php ENDPATH**/ ?>