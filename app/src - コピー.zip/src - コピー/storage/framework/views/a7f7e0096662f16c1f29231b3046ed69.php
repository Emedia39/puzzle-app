<html lang=“ja”>
<body>
<h1>■ログイン画面</h1><!--変数で出力-->
　
<form method="post" action=<?php echo e(url('login')); ?>>
    <?php echo csrf_field(); ?><!--CSRF来策・やらないとララベルが判断して419エラー-->
    <input name="name">
    <input name="password">
    <input type="submit" name='doLogin'></input>
</form>
<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

</body>
</html>
<?php /**PATH /var/www/resources/views/auth/index.blade.php ENDPATH**/ ?>