<div>
    <!-- We must ship. - Taylor Otwell -->
</div>
<html lang=“ja”>
<body>
<h1>■<?php echo e($title); ?></h1><!--変数で出力・$title{}{}-->



<ul>
    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>名前：<?php echo e($account['name']); ?> * パスワード：<?php echo e($account['password']); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<form method="post" action=<?php echo e(url('logout')); ?>>
    <?php echo csrf_field(); ?><!--CSRF来策・やらないとララベルが判断して419エラー-->
    <button type="submit" name='logout'>戻る</button>
</form>

</body>
</html>
<?php /**PATH /var/www/resources/views/accounts/index.blade.php ENDPATH**/ ?>